import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Admin from './Components/Admin/Layout'
import 'remixicon/fonts/remixicon.css'
import Products from './Components/Admin/Products'
import NotFound from './Components/NotFound'
import Orders from './Components/Admin/Orders'
function App() {
  return (
    <>
    <BrowserRouter>
    <Routes>
      <Route path='/admin'>
      <Route path='products' element={<Products/>}/>
      <Route path='orders' element={<Orders/>}/>
      </Route>
      <Route path='*' element = {<NotFound/>}/>
    </Routes>
    </BrowserRouter>
   
    </>
  )
}

export default App
