const NotFound = () => {
    return(
        <>
        <div className="bg-slate-100 h-screen flex items-center justify-center">
        <h1 className="font-semibold text-2xl">Page Not Found || 404</h1>
        </div>
        </>
    )
}
export default NotFound