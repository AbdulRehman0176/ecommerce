import Layout from "./Layout"
const Products = () => {
    return(
        <>
        <Layout>
            <div>

        <h2>THis is products section</h2>
            </div>
        </Layout>
        </>
    )
}
export default Products