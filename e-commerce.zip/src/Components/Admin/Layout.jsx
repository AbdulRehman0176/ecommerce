import React, { useState } from 'react'
import { Link , useLocation} from 'react-router-dom'
function Layout({children}) {
    const[size, setSize] = useState(280)
    const[accountMenu ,setAccountMenu] = useState(false)

   const location = useLocation();
   console.log(location)

   const menus = [
    {
      to : '/admin/products',
      label: 'Products',
      icon : <i className="ri-shopping-cart-line mr-2"></i>
    },
    {
      to : '/admin/orders',
      label: 'Orders',
      icon : <i className="ri-shape-line mr-2"></i>
    }
   ]
  return (
    <>
     <div>
      <aside className=' bg-indigo-600  fixed top-0 left-0 h-full' style={{width:size, transition:'0.5s'}}>
      <div className='flex flex-col gap-2 p-4'>
        {
          menus.map((item, index)=>(
            <Link to={item.to} className=' w-full p-3 rounded-md text-white hover:bg-rose-600'>
                {item.icon}{item.label}  
            </Link>
          ))
        }
       </div>
      </aside>

      <section className='bg-gray-100 h-full ' style={{marginLeft:size , transition:'0.5s'}}>

      <nav className='p-6 bg-white shadow-lg flex items-center justify-between sticky top-0'>

        <div className='flex items-center gap-1 justify-between'>
            <button onClick={()=>setSize(size === 0 ? 280 : 0)}>
            <i className ="ri-menu-2-line text-2xl p-3 hover:bg-indigo-600 hover:text-white"></i>
            </button>
            <h1 className='text-md font-semibold'>ShopCode</h1>
        </div>

        <div>
            <button onClick={() => setAccountMenu(!accountMenu)}>
            <img src='/images/profile.jpg' className='w-10 h-10 rounded-full'/>
            </button>
            {
              accountMenu && 
                <div className='bg-white shadow-lg absolute top-20 right-5 '>
                <div className='p-6 text-center'>
                    <h1 className='font-semibold'>Abdul Rehman</h1>
                    <p>abdulrehman@gmail.com</p>
                    <div className='h-px bg-gray-200 my-3'></div>
                    <button className=''>
                    <i className="ri-logout-circle-line"></i> Logout</button>
                </div>
                </div>   
            }
            
        </div>
      </nav>
      <div>
        {children}
      </div>
      </section>
    </div>
    </>
  )
}

export default Layout
