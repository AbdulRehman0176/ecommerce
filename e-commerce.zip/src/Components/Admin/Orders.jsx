    import { useState } from "react"
    import Layout from "./Layout"
    const Orders = () => {
        const[orders , setOrders] = useState([
            {
                orderId : '#am0022',
                coustomerName:'AbdulRehman',
                email:'abdulrehman@gmai.com',
                mobile:'03062354233',
                product: 'Leptop Core i7 ',
                amount:'75000',
                date : '30-07-2024 11:15 am',
            },
            {
                orderId : '#am0022',
                coustomerName:'AbdulRehman',
                email:'abdulrehman@gmai.com',
                mobile:'03062354233',
                product: 'Leptop Core i7 ',
                amount:'75000',
                date : '30-07-2024 11:15 am',
            },
            {
                orderId : '#am0022',
                coustomerName:'AbdulRehman',
                email:'abdulrehman@gmai.com',
                mobile:'03062354233',
                product: 'Leptop Core i7 ',
                amount:'75000',
                date : '30-07-2024 11:15 am',
            },
            {
                orderId : '#am0022',
                coustomerName:'AbdulRehman',
                email:'abdulrehman@gmai.com',
                mobile:'03062354233',
                product: 'Leptop Core i7 ',
                amount:'75000',
                date : '30-07-2024 11:15 am',
            },
            {
                orderId : '#am0022',
                coustomerName:'AbdulRehman',
                email:'abdulrehman@gmai.com',
                mobile:'03062354233',
                product: 'Leptop Core i7 ',
                amount:'75000',
                date : '30-07-2024 11:15 am',
            },
            {
                orderId : '#am0022',
                coustomerName:'AbdulRehman',
                email:'abdulrehman@gmai.com',
                mobile:'03062354233',
                product: 'Leptop Core i7 ',
                amount:'75000',
                date : '30-07-2024 11:15 am',
            },
            {
                orderId : '#am0022',
                coustomerName:'AbdulRehman',
                email:'abdulrehman@gmai.com',
                mobile:'03062354233',
                product: 'Leptop Core i7 ',
                amount:'75000',
                date : '30-07-2024 11:15 am',
            },
            {
                orderId : '#am0022',
                coustomerName:'AbdulRehman',
                email:'abdulrehman@gmai.com',
                mobile:'03062354233',
                product: 'Leptop Core i7 ',
                amount:'75000',
                date : '30-07-2024 11:15 am',
            },
            {
                orderId : '#am0022',
                coustomerName:'AbdulRehman',
                email:'abdulrehman@gmai.com',
                mobile:'03062354233',
                product: 'Leptop Core i7 ',
                amount:'75000',
                date : '30-07-2024 11:15 am',
            }

        ])
        return(
            <>
            <Layout>
            <div className="p-4">
                <h1 className="text-3xl font-semibold">Orders Details</h1>
                <div>
                    <table className="w-full mt-4 text-center">
                        <thead className="bg-red-500">
                            <tr className="text-white">
                                <td className="p-3">Order ID</td>
                                <td>Coustomer's Name</td>
                                <td>Email</td>
                                <td>Mobile</td>
                                <td>Product</td>
                                <td>Amount</td>
                                <td>Date</td>
                                <td>Status</td>
                            </tr>
                        </thead>
                        <tbody>
                                    {
                                        orders.map((items, index)=>[ 
                                            <tr key={index} style={{
                                                background: (index+1)%2 === 0 ? '#f1f5f9' : 'white'
                                            }}>
                                            <td className="p-6">{items.orderId}</td>
                                            <td>{items.coustomerName}</td>
                                            <td>{items.email}</td>
                                            <td>{items.mobile}</td>
                                            <td>{items.product}</td>
                                            <td>{items.amount.toLocaleString()}</td>
                                            <td>{items.date}</td>
                                            <td>
                                                <select className="p-1 border-2" >
                                                    <option value="pending" >Pending</option>
                                                    <option value="processing">Processing</option>
                                                    <option value="disPatched">DisPatched</option>
                                                    <option value="return">Return</option>
                                                </select>
                                            </td>
                                        </tr>
                            
                                        ])
                                    
                                    }
                            </tbody>
                    </table>
                </div>
            </div>
            </Layout>
            </>
        )
    }
    export default Orders